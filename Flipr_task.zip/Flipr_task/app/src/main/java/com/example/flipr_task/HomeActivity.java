package com.example.flipr_task;

import android.app.Dialog;
import java.util.Calendar;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;


public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth mAuth;
    private Button add;
    private ArrayList<String> list;
    private ArrayAdapter<String> adapter;
    private long currentTime = Calendar.getInstance().getTimeInMillis(), t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAuth = FirebaseAuth.getInstance();
        load_data();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
        add = findViewById(R.id.add_board);
        add.setOnClickListener(this);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(HomeActivity.this, CardActivity.class);
                i.putStringArrayListExtra("list", list);
                i.putExtra("pos", position);
                startActivity(i);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String s = parent.getItemAtPosition(position).toString();
                long_press_menu(s, position);
                return true;
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.logout){
            mAuth.signOut();
            finish();
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
    private void add_new(){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_new_board);

        final EditText editText = dialog.findViewById(R.id.ed);
        final Button add = dialog.findViewById(R.id.a);
        final Button cancel = dialog.findViewById(R.id.c);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = editText.getText().toString();
                if(TextUtils.isEmpty(s)) {
                    Toast.makeText(HomeActivity.this, "Please enter board name", Toast.LENGTH_SHORT).show();
                    return;
                }
                list.add(s);
                editText.setText("");
                adapter.notifyDataSetChanged();
                save_data();
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
}

    private void save_data(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String email = currentUser.getEmail();
            SharedPreferences sharedPreferences = getSharedPreferences(email , MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            Gson gson = new Gson();
            String json = gson.toJson(list);
            editor.putString("task list" , json);
            editor.apply();
        }
    }

    private void load_data(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String email = currentUser.getEmail();
            SharedPreferences sharedPreferences = getSharedPreferences(email , MODE_PRIVATE);
            Gson gson = new Gson();
            String json = sharedPreferences.getString("task list", null);
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            list = gson.fromJson(json, type);

            if (list == null) {
                list = new ArrayList<>();
            }
        }
    }

    private void long_press_menu(String s, final int position){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.list_menu);

        final TextView textView = dialog.findViewById(R.id.nme);
        final Button share = dialog.findViewById(R.id.share);
        final Button pin = dialog.findViewById(R.id.pin);
        final Button delete = dialog.findViewById(R.id.delete);

        textView.setText(s);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list.remove(position);
                adapter.notifyDataSetChanged();
                save_data();
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    @Override
    public void onClick(View v) {
        if(v == add){
            add_new();
        }
    }
}
