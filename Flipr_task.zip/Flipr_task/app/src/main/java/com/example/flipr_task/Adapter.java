package com.example.flipr_task;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import java.util.HashMap;
import java.util.List;

public class Adapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> stringList; // header titles
    // child data in format of header title, child title
    private HashMap<String, List<String>> card;

    public  Adapter(Context context, List<String> stringList, HashMap<String, List<String>> card){
        this.context = context;
        this.stringList = stringList;
        this.card = card;
    }

    @Override
    public int getGroupCount() {
        return this.stringList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return this.card.get(this.stringList.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this.stringList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return this.card.get(this.stringList.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.listview, null);
        }

        TextView list_val = convertView.findViewById(R.id.lst);
        list_val.setTypeface(null, Typeface.BOLD);
        list_val.setText(headerTitle);


        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final String childText = (String) getChild(groupPosition, childPosition);

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.cardview, null);
        }

        TextView card_val = convertView.findViewById(R.id.crd);
        card_val.setText(childText);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }


}
