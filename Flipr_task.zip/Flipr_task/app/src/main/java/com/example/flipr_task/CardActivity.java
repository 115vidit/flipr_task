package com.example.flipr_task;

import java.util.Calendar;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.google.gson.Gson;
import android.content.SharedPreferences;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class CardActivity extends AppCompatActivity implements View.OnClickListener {

    private Button add;
    private Adapter adapter;
    private List<String> stringList;
    private ArrayList<String> list;
    private int position;
    private HashMap<String, List<String>> card;
    private List<String> a, lp;
    private ArrayList<List<String>> listArrayList;
    private long currentTime = Calendar.getInstance().getTimeInMillis();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);
        list = getIntent().getStringArrayListExtra("list");
        position = getIntent().getIntExtra("pos", position);
        load_data();
        adapter = new Adapter(this, stringList, card);
        ExpandableListView listView = findViewById(R.id.card_list);
        listView.setAdapter(adapter);
        listView.setOnChildClickListener(click_child);
        add = findViewById(R.id.add_card);
        add.setOnClickListener(this);
    }
    private void add_new(){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_new_list);

        final EditText editText = dialog.findViewById(R.id.ed);
        final Button add = dialog.findViewById(R.id.a);
        final Button cancel = dialog.findViewById(R.id.c);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = editText.getText().toString();
                if(TextUtils.isEmpty(s)) {
                    Toast.makeText(CardActivity.this, "Please enter list name", Toast.LENGTH_SHORT).show();
                    return;
                }
                stringList.add(s);
                editText.setText("");
                a = new ArrayList<String>();
                a.add(getString(R.string.add));
                listArrayList.add(a);
                card.put(stringList.get(stringList.size()-1), a);
                adapter.notifyDataSetChanged();
                save_data();
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void add_new_list(final int groupPosition){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_new_card);

        final EditText editText = dialog.findViewById(R.id.card);
        final Button add = dialog.findViewById(R.id.a);
        final Button cancel = dialog.findViewById(R.id.c);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = editText.getText().toString();
                if(TextUtils.isEmpty(s)) {
                    Toast.makeText(CardActivity.this, "Please enter card name", Toast.LENGTH_SHORT).show();
                    return;
                }
                a.add(s);
                listArrayList.add(a);
                editText.setText("");
                card.put(stringList.get(groupPosition), a);
                adapter.notifyDataSetChanged();
                save_data();
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    private ExpandableListView.OnChildClickListener click_child = new ExpandableListView.OnChildClickListener() {
        @Override
        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
            lp = listArrayList.get(childPosition);
            int p = lp.indexOf(getString(R.string.add));
            if(childPosition == p){
                add_new_list(groupPosition);
            }
            else{
                Intent i = new Intent(CardActivity.this, TasksActivity.class);
                startActivity(i);
            }
            return false;
        }
    };

    private void load_data(){
        if (list != null) {
            SharedPreferences sharedPreferences = getSharedPreferences("task" + list.get(position), MODE_PRIVATE);
            Gson gson = new Gson();
            String json = sharedPreferences.getString("task", null);
            String json1 = sharedPreferences.getString("t", null);
            String json3 = sharedPreferences.getString("to", null);
            String json5 = sharedPreferences.getString("vo", null);
            String json4 = sharedPreferences.getString("po", null);
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            Type type1 = new TypeToken<HashMap<String, List<String>>>(){}.getType();
            Type type2 = new TypeToken<ArrayList<ArrayList<String>>>() {}.getType();
            stringList = gson.fromJson(json, type);
            card = gson.fromJson(json1, type1);
            lp = gson.fromJson(json3, type);
            a = gson.fromJson(json5, type);
            listArrayList = gson.fromJson(json4, type2);

            if (stringList == null) {
                stringList = new ArrayList<>();
            }
            if (card == null) {
                card = new HashMap<>();
            }
            if (lp == null) {
                lp = new ArrayList<>();
            }
            if (listArrayList == null) {
                listArrayList = new ArrayList<>();
            }
            if (a == null) {
                a = new ArrayList<>();
            }
        }
    }

    private void save_data() {
        if (list != null) {
            SharedPreferences sharedPreferences = getSharedPreferences("task" + list.get(position), MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            Gson gson = new Gson();
            String json = gson.toJson(stringList);
            String json2 = gson.toJson(card);
            String json5 = gson.toJson(a);
            String json3 = gson.toJson(lp);
            String json4 = gson.toJson(listArrayList);
            editor.putString("task", json);
            editor.putString("t", json2);
            editor.putString("to", json3);
            editor.putString("po", json4);
            editor.putString("vo", json5);
            editor.apply();
        }
    }

    @Override
    public void onClick(View v) {
        if(v == add){
            add_new();
        }
    }
}
