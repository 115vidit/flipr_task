package com.example.flipr_task;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseUser;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class TasksActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView att;
    private EditText card_desc;
    private String PathHolder;
    private ArrayList<String> list;
    private ArrayAdapter<String> adapter;
    private String name, s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);
        //StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        //StrictMode.setVmPolicy(builder.build());

        load_data();
        att = findViewById(R.id.attach);
        card_desc = findViewById(R.id.card_desc);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        ListView x = findViewById(R.id.get);
        x.setAdapter(adapter);

        att.setOnClickListener(this);
        s = card_desc.getText().toString();

        x.setOnItemClickListener(show);
        x.setOnItemLongClickListener(del);

    }

    private void attachments(){
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.attachments);

        final Button files = dialog.findViewById(R.id.file);
        final Button link = dialog.findViewById(R.id.link);

        files.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, 7);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void Delete(final int position){
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        String title = "Delete Attachment ?";
        ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(0xff33b5e5);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(title);
        spannableStringBuilder.setSpan(foregroundColorSpan, 0, title.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        alertDialogBuilder.setTitle(spannableStringBuilder);
        alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                list.remove(position);
                save_data();
                adapter.notifyDataSetChanged();
            }
        });
        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 7 && resultCode == RESULT_OK){
            Uri uri = data.getData();
            File file = new File(uri.getPath());
            PathHolder = file.getAbsolutePath();
            name = data.getData().getLastPathSegment();
            list.add(name);
            adapter.notifyDataSetChanged();
            save_data();
        }
    }

    AdapterView.OnItemClickListener show = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent i = new Intent(Intent.ACTION_VIEW);
            File file = new File(PathHolder);
            Uri uri = Uri.fromFile(file);
            i.setDataAndType(uri, "*/*");
            try {
                startActivity(i);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    AdapterView.OnItemLongClickListener del = new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            Delete(position);
            return false;
        }
    };

    private void save_data(){
            SharedPreferences sharedPreferences = getSharedPreferences("t" , MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            Gson gson = new Gson();
            String json = gson.toJson(list);
            String json1 = gson.toJson(s);
            editor.putString("task list" , json);
            editor.putString("task" , json1);
            editor.apply();
    }

    private void load_data(){
            SharedPreferences sharedPreferences = getSharedPreferences("t" , MODE_PRIVATE);
            Gson gson = new Gson();
            String json = sharedPreferences.getString("task list", null);
            String json2 = sharedPreferences.getString("task", null);
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            Type type2 = new TypeToken<String>() {}.getType();
            list = gson.fromJson(json, type);
            s = gson.fromJson(json2, type2);

            if (list == null) {
                list = new ArrayList<>();
            }
    }

    @Override
    public void onClick(View v) {
        if(v == att){
            attachments();
        }
    }
}
